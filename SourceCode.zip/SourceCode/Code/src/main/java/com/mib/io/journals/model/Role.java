package com.mib.io.journals.model;

public enum Role {
	USER, PUBLISHER
}