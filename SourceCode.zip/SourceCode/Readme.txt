
Important notes:
	DO NOT TRY TO SETUP AND RUN THE APPLICATION, it will only waste time.

What to do?
	Import the code in your favorite IDE
	Perform a code review for coding and technical design issues.
	Do not fix the found issues, just list them down in a text file for your own reference.

Functional Specifications --------------- ---------------------

The system should allow publishing and subscribing to medical journals in a secure way. The system is supposed to implement the following specifications:

    For publishers

        A web portal to upload and manage a list of medical journals

        To upload journals in PDF format

    For public users

        A web portal to find and subscribe to journals of their interest

        Once subscribed the users should be able to browse and read journals online

	Medical journals are a series of issues. Each issue is a text and image intensive PDF document. Public users can subscribe to multiple journals. Once subscribed all issues of a journal are available to the user.